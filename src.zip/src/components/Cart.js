import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { NavLink } from 'react-router-dom'
import { delCart } from '../redux/action'

const Cart = () => {
  const state = useSelector((state) => state.handleCart)
  const dispatch = useDispatch()
  console.log('cartstate', state)
  const [qty, setQty] = useState(0)

  const cartItems = (cartItem) => {
    const handleClose = (item) => {
      dispatch(delCart(item))
    }

    return (
      <>
        <div className="row">
          <div className="col-md-12">
            <div className="px-4 my-5 bg-light rounded-3" key={cartItem.id}>
              <div className="container py-4">
                <button
                  className="btn-close float-end"
                  aria-label="Close"
                  onClick={() => handleClose(cartItem)}
                ></button>

                <div className="row justify-content-center">
                  <div className="col-md-4">
                    <img
                      src={cartItem.image}
                      alt={cartItem.title}
                      height="200px"
                      width="180px"
                    />
                  </div>
                  <div className="col-md-4">
                    <h3>{cartItem.title}</h3>
                    <p className="lead fw-bold">
                      {cartItem.price}$ x {qty} = {cartItem.price * qty}$
                    </p>
                    <div className="form-outline">
                      <label
                        className="form-label lead fw-bold"
                        htmlFor="typeNumber"
                      >
                        Quantity
                      </label>
                      <input
                        onChange={(e) => setQty(e.target.value)}
                        value={qty}
                        type="number"
                        id="typeNumber"
                        className="form-control w-25"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    )
  }

  const emptyCart = () => {
    return (
      <div className="px-4 my-5 bg-light rounded-3 py-5">
        <div className="container py-4">
          <div className="row">
            <h3 className="lead fw-bolder">CART IS EMPTY</h3>
          </div>
        </div>
      </div>
    )
  }

  const button = () => {
    return (
      <div className="container">
        <div className="row">
          <NavLink
            to="/checkout"
            className="btn btn-outline-primary w-25 mb-5 mx-auto"
          >
            Proceed To Checkout
          </NavLink>
        </div>
      </div>
    )
  }
  var total = 0
  const priceList = (price) => {
    var productprc = qty * price.price

    total = total + productprc
    return (
      <ul className="list-group mb-3">
        <li className="list-group-item d-flex justify-content-between lh-sm">
          <div>
            <h6 className="my-0">
              {price.title}--{price.price}$ x {qty}
            </h6>
          </div>
          <span className="text-muted">{price.price * qty}$</span>
        </li>
      </ul>
    )
  }

  return (
    <>
      {state.length === 0 && emptyCart()}

      {state.length !== 0 && state.map(cartItems)}

      {state.length !== 0 && button()}
      <div className="row">
        <div className="col-12 mb-5">
          <h1 className="text-center display-6 fw-bolder">Price List</h1>
          <hr />
        </div>
      </div>
      {state.length !== 0 && state.map(priceList)}

      <li className="mx-3 list-group-item d-flex justify-content-between lh-sm mb-5">
        <strong>Total </strong>
        <strong>{total}$</strong>
      </li>
    </>
  )
}

export default Cart
