import React from 'react'

const Checkout = () => {
  return <div>ss</div>
}

export default Checkout
